import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import './main.css';
import MovieItem from "./MovieItem";

function MovieList() {
    const navigate = useNavigate();
    const [movieList, setMovieList] = useState([]);

    function getMovieList(url) {
        fetch(url)
            .then(response => { return response.json(); })
            .then(data => { setMovieList(data); })
    }

    useEffect(() => { getMovieList('/findAllMovies') }, []);  // ==> MovieList가 로드되었을 때 최초 1회만 호출

    return (
        <div>
            <h2>영화 리스트</h2>
            <button type="button" onClick={() => navigate('/writeMovie')}>영화 등록</button>
            <div style={{
                display: 'grid',
                gridTemplateRows: '1fr',
                gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr'
            }}>
                {movieList.map(
                    ({ movie_id, title, price }) => (
                        <MovieItem movie_id={movie_id}
                                   title={title}
                                   price={price} />
                    )
                )}
            </div>
        </div>
    )
}
export default MovieList;
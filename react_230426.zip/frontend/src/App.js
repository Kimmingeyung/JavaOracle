import React from "react";
import { Routes, Route } from 'react-router';
import { BrowserRouter } from "react-router-dom";

import MovieList from "./components/MovieList";
import WriteMovie from "./components/WriteMovie";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MovieList />} />
          <Route path="/writeMovie" element={<WriteMovie />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
